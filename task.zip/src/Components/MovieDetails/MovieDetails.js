import React, { Component } from 'react'
import { Container,Row,Col } from 'react-bootstrap';
import './MovieDetails.css'


class MovieDetails extends Component {
        constructor(props) {
          super(props)
        
          this.state = {
             items: this.props.location.state
          };
        };
        
    componentDidMount(){
        
        console.log(this.state.items)
    }
    
    render() {
        const post = this.state
        return (
            <div className='body'>
                <Container fluid>
                    <Row>
                        <Col> <h1 className='left-align'>Movie details</h1>
                             <h2 className='left-align'>{post.items.items.name}</h2>
                             <h2 className="left-align">{post.items.items.genres}</h2>
                             <h2 className="left-align">{post.items.items.rating.average}</h2>
                             <h2 className="left-align">{post.items.items.runtime}</h2>
                             <h2 className="left-align">{post.items.items.summary}</h2>
                            </Col>
                         <Col> <img className='img-comtainer' src={post.items.items.image.medium} alt="" />
                    
                             </Col>
                    </Row>
                 </Container>
               
               
            </div>
        )
    }
}

export default MovieDetails
